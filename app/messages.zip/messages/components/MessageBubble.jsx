// app/messages/components/MessageBubble.jsx
// ✅ FIXED - Shows username instead of "Them" in reply

import React from 'react';
import { Check, Star, File, CornerDownRight } from 'lucide-react';
import MessageActions from './MessageActions';
import MessageHelpers from './MessageHelpers';

const MessageBubble = ({ 
    msg, 
    currentUser,
    currentChat, // ✅ NEW - Pass currentChat to get username
    onEdit, 
    onDelete, 
    onReply 
}) => {
    const isMyMessage = msg.sender === 'me';
    const isDeleted = msg.deletedAt;
    
    // ✅ Get the other user's username for reply preview
    const otherUsername = currentChat?.user?.name || 'User';
    
    return (
        <div className={`flex ${isMyMessage ? 'justify-end' : 'justify-start'} group mb-3`}>
            <div className={`flex gap-2 items-end max-w-[70%] ${isMyMessage ? 'flex-row-reverse' : 'flex-row'}`}>
                {/* Message Actions Dropdown */}
                <MessageActions
                    message={msg}
                    currentUserId={currentUser.id}
                    onEdit={onEdit}
                    onDelete={onDelete}
                    onReply={onReply}
                />
                
                {/* Message Bubble */}
                <div
                    className={`px-3 py-2 rounded-2xl relative ${
                        isMyMessage
                            ? 'bg-gradient-to-r from-blue-500 to-purple-500 text-white rounded-br-md'
                            : 'bg-slate-800 text-white rounded-bl-md'
                    } ${msg.hasKeywords ? 'ring-2 ring-purple-400/50 ring-offset-2 ring-offset-slate-900' : ''} ${
                        isDeleted ? 'opacity-60' : ''
                    }`}
                >
                    {/* ✅ REPLY PREVIEW - Shows username */}
                    {msg.replyTo && (
                        <div className={`mb-2 p-2 rounded-lg border-l-4 ${
                            isMyMessage 
                                ? 'bg-white/10 border-white/30' 
                                : 'bg-white/5 border-purple-500/50'
                        }`}>
                            <div className="flex items-center gap-1 mb-1">
                                <CornerDownRight className="w-3 h-3 opacity-60" />
                                <p className="text-xs opacity-80 font-semibold">
                                    {/* ✅ FIXED - Shows actual username */}
                                    {msg.replyTo.sender === 'me' ? 'You' : `@${otherUsername}`}
                                </p>
                            </div>
                            <p className={`text-xs opacity-70 line-clamp-2 ${
                                msg.replyTo.isDeleted ? 'italic' : ''
                            }`}>
                                {msg.replyTo.isDeleted && '🚫 '}
                                {msg.replyTo.fileName ? `📎 ${msg.replyTo.fileName}` : msg.replyTo.text}
                            </p>
                        </div>
                    )}

                    {/* Message Content */}
                    <p className={`break-words ${isDeleted ? 'italic' : ''}`}>
                        {isDeleted ? (
                            <span className="flex items-center gap-2">
                                <span className="opacity-50">🚫</span>
                                This message was deleted
                            </span>
                        ) : (
                            msg.text
                        )}
                    </p>

                    {/* File Attachment */}
                    {msg.fileUrl && !isDeleted && (
                        <div className="mt-2">
                            {msg.fileType?.startsWith('image/') ? (
                                <img
                                    src={msg.fileUrl}
                                    alt={msg.fileName}
                                    loading="lazy"
                                    className="max-w-xs rounded-lg cursor-pointer hover:opacity-90 transition-opacity"
                                    onClick={() => window.open(msg.fileUrl, '_blank')}
                                />
                            ) : (
                                <a
                                    href={msg.fileUrl}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className={`flex items-center gap-2 p-2 rounded-lg hover:bg-white/10 transition-colors ${
                                        isMyMessage ? 'bg-white/10' : 'bg-white/5'
                                    }`}
                                >
                                    <File className="w-4 h-4 text-purple-400" />
                                    <span className="text-sm truncate max-w-[200px]">
                                        {msg.fileName}
                                    </span>
                                </a>
                            )}
                        </div>
                    )}

                    {/* Swap Keywords Badge */}
                    {msg.hasKeywords && !isDeleted && (
                        <div className={`mt-2 inline-flex items-center gap-1 text-xs rounded-full px-2 py-1 ${
                            isMyMessage
                                ? 'text-blue-200 bg-blue-500/30'
                                : 'text-purple-200 bg-purple-500/30'
                        }`}>
                            <Star className="w-3 h-3" />
                            <span>Swap keywords detected</span>
                        </div>
                    )}

                    {/* Message Footer (Time + Status) */}
                    <div className="flex items-center justify-end gap-1 mt-1">
                        {/* Edited indicator */}
                        {msg.editedAt && !isDeleted && (
                            <span className="text-xs opacity-60">edited</span>
                        )}
                        
                        {/* Timestamp */}
                        <span className="text-xs opacity-70">
                            {MessageHelpers.formatTime(msg.timestamp)}
                        </span>
                        
                        {/* Read receipts (for own messages only) */}
                        {isMyMessage && !isDeleted && (
                            <div className="flex">
                                <Check 
                                    className={`w-3 h-3 ${
                                        msg.read ? 'text-blue-400' : 'text-gray-400'
                                    }`} 
                                />
                                {msg.read && (
                                    <Check className="w-3 h-3 text-blue-400 -ml-2" />
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MessageBubble;